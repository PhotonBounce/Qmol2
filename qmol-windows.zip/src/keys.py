"""API-key management + usage tracking (SQLite).

Schema:
  api_keys(key PK, email, tier, monthly_quota, created_at, active)
  usage(ts, key, endpoint, smiles_count)

Tiers map to monthly quotas (SMILES processed per calendar month):
  free        -> 500        (no key needed; tracked by IP elsewhere)
  research    -> 10_000
  commercial  -> 100_000
  redistrib   -> 1_000_000

Called from:
  - stripe_webhook.deliver() when a purchase completes
  - api.py  to authenticate + increment usage

Local test:
    python -c "from src.keys import provision; print(provision('a@b.com','commercial'))"
"""
from __future__ import annotations
import hashlib
import os

import bcrypt
import secrets
import sqlite3
import time
from dataclasses import dataclass
from pathlib import Path

DEFAULT_DB = Path(os.getenv("QMOL_KEYS_DB", "data/keys.sqlite"))

PEPPER = os.getenv("API_KEY_PEPPER", "").encode()


def _hash_key(key: str) -> bytes:
    """Hash an API key with bcrypt + optional pepper."""
    combined = key.encode() + PEPPER
    return bcrypt.hashpw(combined, bcrypt.gensalt(rounds=12))


def _verify_key(key: str, stored_hash: bytes) -> bool:
    """Verify an API key against a bcrypt hash."""
    combined = key.encode() + PEPPER
    return bcrypt.checkpw(combined, stored_hash)

TIER_QUOTA = {
    "free": 500,
    "trial": 10_000,
    "research": 10_000,
    "commercial": 100_000,
    "redistribution": 1_000_000,
    "enterprise": 10_000_000,
}

SCHEMA = """
CREATE TABLE IF NOT EXISTS api_keys (
    key           TEXT PRIMARY KEY,
    key_hash      BLOB,
    email         TEXT NOT NULL,
    tier          TEXT NOT NULL,
    monthly_quota INTEGER NOT NULL,
    created_at    TEXT DEFAULT (datetime('now')),
    active        INTEGER DEFAULT 1
);
CREATE INDEX IF NOT EXISTS idx_email ON api_keys(email);

CREATE TABLE IF NOT EXISTS usage (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    ts            TEXT DEFAULT (datetime('now')),
    key           TEXT NOT NULL,
    endpoint      TEXT,
    smiles_count  INTEGER DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_usage_key ON usage(key);
CREATE INDEX IF NOT EXISTS idx_usage_ts ON usage(ts);
"""


@dataclass
class KeyInfo:
    key: str
    email: str
    tier: str
    monthly_quota: int
    active: bool


def _connect(db: Path | None = None) -> sqlite3.Connection:
    db = db or DEFAULT_DB
    db.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(db)
    conn.executescript(SCHEMA)
    conn.commit()
    return conn


def _generate(email: str) -> str:
    rand = secrets.token_hex(16)
    tag = hashlib.sha256(f"{email}|{rand}|{time.time()}".encode()).hexdigest()[:24]
    return f"qmol_{tag}"


def provision(email: str, tier: str = "research", db: Path | None = None) -> KeyInfo:
    """Create (or return existing active) API key for buyer+tier."""
    tier = tier.lower()
    if tier not in TIER_QUOTA:
        raise ValueError(f"unknown tier: {tier}")
    quota = TIER_QUOTA[tier]
    conn = _connect(db)
    row = conn.execute(
        "SELECT key FROM api_keys WHERE email=? AND tier=? AND active=1",
        (email, tier),
    ).fetchone()
    if row:
        k = row[0]
    else:
        k = _generate(email)
        key_hash = _hash_key(k)
        conn.execute(
            "INSERT INTO api_keys (key, key_hash, email, tier, monthly_quota) VALUES (?,?,?,?,?)",
            (k, key_hash, email, tier, quota),
        )
        conn.commit()
    conn.close()
    return KeyInfo(key=k, email=email, tier=tier, monthly_quota=quota, active=True)


def lookup(key: str, db: Path | None = None) -> KeyInfo | None:
    conn = _connect(db)
    # Try exact match first (backward compatible with unmigrated keys)
    row = conn.execute(
        "SELECT key, key_hash, email, tier, monthly_quota, active FROM api_keys WHERE key=?",
        (key,),
    ).fetchone()
    if row:
        # If there's a hash stored, verify it; otherwise accept exact match
        if row[1] is not None and not _verify_key(key, row[1]):
            conn.close()
            return None
        conn.close()
        return KeyInfo(key=row[0], email=row[2], tier=row[3],
                       monthly_quota=row[4], active=bool(row[5]))
    # Fallback: verify against all stored hashes (O(N) — acceptable for <1000 keys)
    cursor = conn.execute(
        "SELECT key, key_hash, email, tier, monthly_quota, active FROM api_keys WHERE key_hash IS NOT NULL"
    )
    for row in cursor.fetchall():
        if row[1] and _verify_key(key, row[1]):
            conn.close()
            return KeyInfo(key=row[0], email=row[2], tier=row[3],
                           monthly_quota=row[4], active=bool(row[5]))
    conn.close()
    return None


def month_usage(key: str, db: Path | None = None) -> int:
    conn = _connect(db)
    row = conn.execute(
        "SELECT COALESCE(SUM(smiles_count),0) FROM usage "
        "WHERE key=? AND ts >= datetime('now','start of month')",
        (key,),
    ).fetchone()
    conn.close()
    return int(row[0])


def record(key: str, endpoint: str, smiles_count: int,
           db: Path | None = None) -> None:
    conn = _connect(db)
    conn.execute(
        "INSERT INTO usage (key, endpoint, smiles_count) VALUES (?,?,?)",
        (key, endpoint, smiles_count),
    )
    conn.commit()
    conn.close()


def deactivate(key: str, db: Path | None = None) -> None:
    conn = _connect(db)
    conn.execute("UPDATE api_keys SET active=0 WHERE key=?", (key,))
    conn.commit()
    conn.close()


def delete_account(key: str, db: Path | None = None) -> dict:
    """Permanently delete the caller's account + all associated data.

    Required by Google Play / GDPR ("delete my account"). Removes every key
    under the same email, plus that key's usage, audit log, scopes, team
    memberships, webhooks, referral code, and magic-link tokens. Missing tables
    (created lazily by their modules) are skipped, not errors.
    """
    conn = _connect(db)
    row = conn.execute("SELECT email FROM api_keys WHERE key=?", (key,)).fetchone()
    if not row:
        conn.close()
        raise ValueError("unknown key")
    email = row[0]
    member_keys = [r[0] for r in conn.execute(
        "SELECT key FROM api_keys WHERE email=?", (email,)).fetchall()]

    def _del(sql: str, params: tuple) -> int:
        try:
            return conn.execute(sql, params).rowcount
        except sqlite3.OperationalError:
            return 0   # table doesn't exist yet

    removed: dict[str, int] = {}
    per_key = [("usage", "key"), ("audit", "api_key"), ("key_scopes", "api_key"),
               ("team_members", "api_key"), ("webhooks", "api_key"),
               ("webhook_deliveries", "api_key"), ("ref_codes", "api_key")]
    for k in member_keys:
        for table, col in per_key:
            removed[table] = removed.get(table, 0) + _del(
                f"DELETE FROM {table} WHERE {col}=?", (k,))
    removed["magic_tokens"] = _del("DELETE FROM magic_tokens WHERE email=?", (email,))
    removed["api_keys"] = _del("DELETE FROM api_keys WHERE email=?", (email,))
    conn.commit()
    conn.close()
    return {"email": email, "keys_deleted": len(member_keys), "removed": removed}
